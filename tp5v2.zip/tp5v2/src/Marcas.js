export default function Marcas() {
    return (  
    <nav className="navbar">
    <div className="container">
      <dt className="navbar-brand" href="#" >
        Marcas con las que trabajamos
      </dt>
    </div>
  </nav>
    );
  }