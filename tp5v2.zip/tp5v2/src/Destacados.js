export default function Destacados() {
    return (
        <nav className="navbar">
        <div className="container" id="destacados">
          <a className="navbar-brand" href="#" >
            <dt>Productos destacados</dt>
          </a>
        </div>
      </nav>    
    );
  }
 