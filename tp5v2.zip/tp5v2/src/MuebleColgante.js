import mueble from './Imagenes/Capa-1.png'

export default function MuebleColgante() {
    return (
  <div className="container">
    <div className="row">
      <div className="col">
        <div className="card text-center btn btn-secondary" >
          <img src={mueble}  className="card-img-top" alt="..."/>
          <div className="card-body">
            <h5 className="MuebleColgante card-title">Lavatorios</h5>
            <p className="MuebleColgante card-text">Mueble colgante para lavatorio</p>
          </div>
        </div>
      </div>
      <div className="col">
        <div className="card text-center btn btn-secondary" >
          <img src={mueble}  className="card-img-top" alt="..."/>
          <div className="card-body">
            <h5 className="MuebleColgante card-title">Lavatorios</h5>
            <p className="MuebleColgante card-text">Mueble colgante para lavatorio</p>
          </div>
        </div>
      </div>
      <div className="col">
        <div className="card text-center btn btn-secondary" >
          <img src={mueble}  className="card-img-top" alt="..."/>
          <div className="card-body">
            <h5 className="MuebleColgante card-title">Lavatorios</h5>
            <p className="MuebleColgante card-text">Mueble colgante para lavatorio</p>
          </div>
        </div>
      </div>
    </div>
    <div className="row">
      <div className="col">
        <div className="card text-center btn btn-secondary" >
          <img src={mueble}  className="card-img-top" alt="..."/>
          <div className="card-body">
            <h5 className="MuebleColgante card-title">Lavatorios</h5>
            <p className="MuebleColgante card-text">Mueble colgante para lavatorio</p>
          </div>
        </div>
      </div>
      <div className="col">
        <div className="card text-center btn btn-secondary" >
          <img src={mueble}  className="card-img-top" alt="..."/>
          <div className="card-body">
            <h5 className="MuebleColgante card-title">Lavatorios</h5>
            <p className="MuebleColgante card-text">Mueble colgante para lavatorio</p>
          </div>
        </div>
      </div>
      <div className="col">
        <div className="card text-center btn btn-secondary" >
          <img src={mueble}  className="card-img-top" alt="..."/>
          <div className="card-body">
            <h5 className="MuebleColgante card-title">Lavatorios</h5>
            <p className="MuebleColgante card-text">Mueble colgante para lavatorio</p>
          </div>
        </div>
      </div>
    </div>
    </div>  
    );
  }
 