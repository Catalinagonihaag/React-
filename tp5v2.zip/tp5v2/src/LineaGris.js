export default function LineaGris() {
    return (
        <nav class="navbar">
        <div id="Linea">
          <a class="navbar-brand"></a>
        </div>
      </nav>
    );
  }
